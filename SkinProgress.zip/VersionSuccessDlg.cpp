#include "StdAfx.h"
#include "RunningLog.h"
#include "AniDialog.h"
#include "VersionSuccessDlg.h"


CVersionSuccessDlg::CVersionSuccessDlg() : CAniDialog(CVersionSuccessDlg::IDD)
{
}


void CVersionSuccessDlg::DoDataExchange(CDataExchange* pDX)
{
    CAniDialog::DoDataExchange(pDX);
}